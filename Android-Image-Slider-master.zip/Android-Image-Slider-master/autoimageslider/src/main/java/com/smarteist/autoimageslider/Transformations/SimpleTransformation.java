package com.smarteist.autoimageslider.Transformations;

import com.smarteist.autoimageslider.SliderPager;
import android.view.View;

public class SimpleTransformation implements SliderPager.PageTransformer {
    @Override
    public void transformPage(View page, float position) {

    }
}