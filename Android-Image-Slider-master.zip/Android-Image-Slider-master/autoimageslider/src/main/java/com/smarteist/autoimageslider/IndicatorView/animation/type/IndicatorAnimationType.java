package com.smarteist.autoimageslider.IndicatorView.animation.type;

public enum IndicatorAnimationType {NONE, COLOR, SCALE, WORM, SLIDE, FILL, THIN_WORM, DROP, SWAP, SCALE_DOWN}
